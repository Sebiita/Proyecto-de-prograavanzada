package cl.duocuc.supermercado;

import cl.duocuc.supermercado.sistema.ControladorSupermercado;

//Punto de entrada del sistema de gestión del supermercado
public class Main {

    public static void main(String[] args) {
        ControladorSupermercado controlador = new ControladorSupermercado();

        //llamada para la persistencia de datos
        //aqui intenta cargar datos previos, si no existen precarga datos de prueba
        controlador.getGuardador().cargarDatos();

        if (controlador.getInventarioTienda().getMapaProductos().isEmpty()
                && controlador.getListaCompradores().isEmpty()) {
            controlador.precargarDatos();
        }

        //Inicia el menú interactivo
        controlador.iniciarMenu();
    }
}
